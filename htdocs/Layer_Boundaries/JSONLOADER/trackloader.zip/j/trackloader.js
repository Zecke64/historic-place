//------------------------------------------------------------------------------
//	$Id: trackloader.js,v 1.5 2014/02/06 15:31:44 wolf Exp wolf $
//------------------------------------------------------------------------------
//	Erklaerung:	http://www.netzwolf.info/kartografie/openlayers/trackloader.htm
//------------------------------------------------------------------------------
//	Fragen, Wuensche, Bedenken, Anregungen?
//	<openlayers(%40)netzwolf.info>
//------------------------------------------------------------------------------

OpenLayers.Control.TrackLoader=OpenLayers.Class(OpenLayers.Control,{

	//----------------------------------------------------------------------
	//	Config
	//----------------------------------------------------------------------

	trackIndex:	'tracks.csv',
	trackPrefix:	'.',
	maxTracks:	10,

	zoomToTracks:	true,	// zoom map to tracks after loading index
	restrictMap:	false,	// restrict map to tracks area
	autoUpdate:	null,	// rebuild tracklist after zoom or pan
	selectFeature:	null,	// if set, loaded tracks will be registered

	trackColors:	['red', 'yellow', 'blue', 'black'],
	trackWidth:	5,
	trackOpacity:	0.8,

	trackCursor:	'pointer',
	descrCursor:	'help',

	textButtonOff:	'No tracks available',
	textButtonOn:	'Update tracklist (${count})',
	textLoadError:	'Error loading file ${url}',

	//----------------------------------------------------------------------
	//	State
	//----------------------------------------------------------------------

	button:		null,
	tracks:		null,
	tracksExtent:	null,
	colorIndex:	0,

	//----------------------------------------------------------------------
	//	Implementation
	//----------------------------------------------------------------------

	initialize: function () {

		OpenLayers.Control.prototype.initialize.apply (this, arguments);
	},

	destroy: function()  {

		if (this.map)
		this.map.events.unregister('moveend', this, this.update);

		if (this.button) this.button.parentElement.removeChild(this.button);
		this.button = null;

		this.destroyLayers();
		this.selectFeature = null;

        	OpenLayers.Control.prototype.destroy.apply(this, arguments); 
	},

	draw: function() {

		OpenLayers.Control.prototype.draw.apply(this);

		var control = this;	// for closure

		this.button = document.createElement('button');
		this.button.innerHTML = this.textButtonOff;
		this.button.disabled = true;
		this.button.onclick = function(evt) {
			if (evt) OpenLayers.Event.stop(evt);
			control.destroyLayers();
			control.update(true);
		};
		this.div.appendChild(this.button);

		if (this.autoUpdate !== false)
		this.map.events.register('moveend', this, this.update);

		this.loadIndex(true);

		return this.div;
	},

	//----------------------------------------------------------------------
	//	Workhorse
	//----------------------------------------------------------------------

	intersects: function (a,b) {

		if (a.left   >= b.right ) return false;
		if (a.right  <= b.left  ) return false;
		if (a.bottom >= b.top   ) return false;
		if (a.top    <= b.bottom) return false;
		return true;
	},

	update: function(full) {

		//--------------------------------------------------------------
		//	Delete layers
		//--------------------------------------------------------------

		if (!this.tracks) {

			this.destroyLayers();
			return false;
		}

		//--------------------------------------------------------------
		//	Get list of visible tracks
		//--------------------------------------------------------------

		var mapExtent = this.map.getExtent().
			transform(map.getProjectionObject(),map.displayProjection);

		this.updateVisibility();

		var tracksInExtent = [];
		var selectedTracks = [];

		for (var i in this.tracks) {

			var track = this.tracks[i];

			if (track.bounds.left   >= mapExtent.right ) continue;
			if (track.bounds.right  <= mapExtent.left  ) continue;
			if (track.bounds.bottom >= mapExtent.top   ) continue;
			if (track.bounds.top    <= mapExtent.bottom) continue;

			tracksInExtent.push (track);

			if (track.visibility) {

				selectedTracks.push(track);
				if (selectedTracks.length >= this.maxTracks) break;
			}
		}

		//--------------------------------------------------------------
		//	Update button
		//--------------------------------------------------------------

		this.button.innerHTML= OpenLayers.String.format(this.textButtonOn,
                                                {count: tracksInExtent.length});
		this.button.disabled = false;

		//--------------------------------------------------------------
		//	Full update?
		//--------------------------------------------------------------

		if (!full && !this.autoUpdate) return;

		//--------------------------------------------------------------
		//	Add invisible tracks to selection
		//--------------------------------------------------------------

		if (tracksInExtent.length <= this.maxTracks) {

			selectedTracks = tracksInExtent;

		} else if (selectedTracks.length<this.maxTracks) {

			var mergedTracks = [];
			var freeSpace = this.maxTracks - selectedTracks.length;

			for (i in tracksInExtent) {

				var track = tracksInExtent[i];

				if (track.visibility || freeSpace-- >0) {

					mergedTracks.push(track);
				}
			}

			selectedTracks = mergedTracks;
		}

		//--------------------------------------------------------------
		//	Match layers and selected tracks
		//--------------------------------------------------------------

		if (this.selectFeature && this.selectFeature.setLayer)
			this.selectFeature.setLayer([]);

		var selectFeatureLayers = [];

		var mapLayers = this.map.layers.slice();

		for (var i in mapLayers) {

			var layer = mapLayers[i];
			if (!layer.track || layer.track.loader != this) continue;

			var index = OpenLayers.Util.indexOf(selectedTracks, layer.track);

			if (index >= 0) {

				selectedTracks.splice (index, 1);
				selectFeatureLayers.push(layer);

			} else {

				layer.track = null;
				layer.events.triggerEvent('loadEnd'); // Hmpf!
				this.map.removeLayer(layer);
				layer.destroy();
			}
		}

		//--------------------------------------------------------------
		//	Add layers
		//--------------------------------------------------------------

		for (var i in selectedTracks) {

			var track = selectedTracks[i];

			//------------------------------------------------------
			//	Or create new layer
			//------------------------------------------------------

			if (!track.color) {

				track.color = this.trackColors
					[this.colorIndex++%this.trackColors.length];
			}

			var layer = new OpenLayers.Layer.Vector (track.title, {

				track: track,
				layerGroup: 'trackloader',

				visibility: track.visibility,

				strategies: [new OpenLayers.Strategy.Fixed()],

				protocol: new OpenLayers.Protocol.HTTP({

					url: this.trackPrefix + track.gpx,
					format: new OpenLayers.Format.GPX()
				}),

				style: {
					strokeColor:	track.color,
					strokeWidth: 	this.trackWidth,
					strokeOpacity:	this.trackOpacity,
					graphicTitle:	track.title,
					cursor:		track.description ? this.descrCursor : this.trackCursor
				}
			});

			this.map.addLayer (layer);
			selectFeatureLayers.push(layer);
		}

		if (this.selectFeature && this.selectFeature.setLayer)
			this.selectFeature.setLayer(selectFeatureLayers);
	},

	//----------------------------------------------------------------------
	//	Copy layer visibility into track visibility
	//----------------------------------------------------------------------

	updateVisibility: function () {

		var mapLayers = this.map.layers.slice();

		for (var i in mapLayers) {

			var layer = mapLayers[i];
			if (!layer.track || layer.track.loader != this) continue;

			layer.track.visibility = layer.visibility;
		}
	},

	//----------------------------------------------------------------------
	//	Destroy layers but keep visibility
	//----------------------------------------------------------------------

	destroyLayers: function() {

		if (this.selectFeature && this.selectFeature.setLayer)
			this.selectFeature.setLayer([]);

		var layers = this.map.layers.slice();

		while (layers.length>0) {

			var layer = layers.shift();

			if (!layer.track || layer.track.loader != this) continue;

			layer.track.visibility = layer.visibility;

			layer.track = null;
			this.map.removeLayer(layer);
			layer.destroy();
		}
	},

	//----------------------------------------------------------------------
	//	Load track index
	//----------------------------------------------------------------------

	loadIndex: function(async) {

		this.tracks      = null;
		this.tracksExtent= null;

		this.button.innerHTML= this.textButtonOff;
		this.button.disabled = true;

		this.destroyLayers();
		this.colorIndex = 0;

		this.events.triggerEvent('loadStart');

		OpenLayers.Request.GET({

			async:	async,
	                url:	this.trackIndex,

	                success: function(request) {

				this.events.triggerEvent('loadEnd');
				this.processIndexCSV(request.responseText);

				if (this.tracksExtent) {

					if (this.zoomToTracks) {

						this.map.zoomToExtent(this.tracksExtent);
					}

					if (this.restrictMap) {

						this.map.setOptions({
						restrictedExtent: this.tracksExtent});
					}
				}

				this.update();
	                },

			failure: function (request) {

				this.events.triggerEvent('loadEnd');
				if (this.zoomToTracks) this.map.zoomToMaxExtent();

				OpenLayers.Console.userError(
					OpenLayers.String.format(this.textLoadError,
						{url: this.trackIndex}));
                	},

			scope: this
	        });
	},

	//----------------------------------------------------------------------
	//	Process track index csv
	//----------------------------------------------------------------------

	processIndexCSV: function(text) {

		var minLon = 180;
		var minLat =  90;
		var maxLon =-180;
		var maxLat = -90;

		var lines = OpenLayers.String.trim(text).split('\n');
		var tracks = [];

		for (lineIndex in lines) {

			var f = OpenLayers.String.trim(lines[lineIndex]).split('\t');

			var l = parseFloat(f[1]);
			var b = parseFloat(f[2]);
			var r = parseFloat(f[3]);
			var t = parseFloat(f[4]);

			if (isNaN(l)||isNaN(b)||isNaN(r)||isNaN(t)) continue;

			tracks.push ({
				loader: this,
				gpx: f[0],
				color: null,
				bounds: new OpenLayers.Bounds (l, b, r, t),
				title: f[5] || f[0],
				description: f[6] || null,
				visibility: false
			});

			if (l < minLon) minLon = l;
			if (b < minLat) minLat = b;
			if (r > maxLon) maxLon = r;
			if (t > maxLat) maxLat = t;
		}

		this.tracks = tracks;

		if (minLon<maxLon && minLat<maxLat) this.tracksExtent =
			new OpenLayers.Bounds(minLon, minLat, maxLon, maxLat).
			transform(map.displayProjection, map.getProjectionObject());
	},

	CLASS_NAME: 'OpenLayers.Control.TrackLoader'
});

//------------------------------------------------------------------------------
//	$Id: trackloader.js,v 1.5 2014/02/06 15:31:44 wolf Exp wolf $
//------------------------------------------------------------------------------
